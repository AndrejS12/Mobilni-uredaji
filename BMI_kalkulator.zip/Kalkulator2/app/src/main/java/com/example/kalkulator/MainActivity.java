package com.example.kalkulator;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private double broj1, broj2;

    private EditText editTextBroj1, editTextBroj2;

    private TextView textViewRezultat;

    private TextView textViewPoruka;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextBroj1 = findViewById(R.id.editTextBroj1);
        editTextBroj2 = findViewById(R.id.editTextBroj2);
        textViewRezultat = findViewById(R.id.textViewRezultat);
        textViewPoruka = findViewById(R.id.textViewPoruka);
    }

    private void takeNumbersFromEditTextAndPutIntoVariables() {
        String tekstBroj1 = editTextBroj1.getText().toString();
        String tekstBroj2 = editTextBroj2.getText().toString();
        broj1 = Double.parseDouble(tekstBroj1);
        broj2 = Double.parseDouble(tekstBroj2);
    }
    public void ClickButtonIzracun(View view)
    {
        takeNumbersFromEditTextAndPutIntoVariables();
        double rezultat = broj1 / Math.pow((broj2/100),2);
        rezultat = Math.round(rezultat * Math.pow(10, 2)) / Math.pow(10, 2);


        if(rezultat >= 18.5 && rezultat <= 25){
            textViewRezultat.setTextColor(Color.GREEN);
            textViewRezultat.setText(Double.toString(rezultat));
            textViewPoruka.setText("Normalna težina");
        }
        else if(rezultat >= 25 && rezultat <= 30){
            textViewRezultat.setTextColor(Color.YELLOW);
            textViewRezultat.setText(Double.toString(rezultat));
            textViewPoruka.setText("Pretili ste");
        }
        else if(rezultat >= 30){
            textViewRezultat.setTextColor(Color.RED);
            textViewRezultat.setText(Double.toString(rezultat));
            textViewPoruka.setText("Pretili ste");
        }
        else if(rezultat >=17 && rezultat <= 18.5){
            textViewRezultat.setTextColor(Color.YELLOW);
            textViewRezultat.setText(Double.toString(rezultat));
            textViewPoruka.setText("Podhranjeni ste");
        }
        else if(rezultat < 17){
            textViewRezultat.setTextColor(Color.RED);
            textViewRezultat.setText(Double.toString(rezultat));
            textViewPoruka.setText("Podhranjeni ste");

        }


    }

}