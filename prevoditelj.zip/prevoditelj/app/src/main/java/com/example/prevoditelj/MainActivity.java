package com.example.prevoditelj;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView textViewGlagoljica;

    private EditText EditTextUpis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewGlagoljica = findViewById(R.id.textViewGlagoljica);

        EditTextUpis = findViewById(R.id.EditTextUpis);
    }

    public void ClickButtonPrevedi(View view){

        String text = "";
        text = EditTextUpis.getText().toString();

        textViewGlagoljica.setText(text);

    }
}