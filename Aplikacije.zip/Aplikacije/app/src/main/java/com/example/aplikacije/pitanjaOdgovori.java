package com.example.aplikacije;

public class pitanjaOdgovori {

    public static String question[] ={
            "Koji nogomentni igrač ima najviše golova?",
            "Tko je bio najbolji strijelac engleske Premier lige u sezoni 2023/2024?",
            "Tko je igrač sa najviše osvojenih trofeja?",
            "Koji igrač nikada nije igrao u Real Madridu?",
            "Koje godine je Cristiano Ronaldo odigrao drugi debitantski nastup za Man. United?",
            "Koji od ovih igrača ima najviše crvenih kartona?",
            "Koliko svjetskih prvenstava je osvojio Pelé?",
            "Tko od ovih igrača igra za Barcelonu u 2024. godini?",
            "Koje godine je Cristiano Ronaldo osvijio svoju prvu zlatnu loptu?",
            "Koji golman je postigao najviše obrana na svjetskom prvenstvu 2022. godine?",
            "Koje godine je Lionel Messi napustio Barcelonu?",
            "Koliko je UCL nalsova kao trener osvojio José Mourinho?",
            "Koja dva tima su igrala u finalu UCL-a 2023. godine?",
            "Tko je od ovih igrača najstariji?",
            "Kada je Luka Modrić potpisao za Tottenham?",
            "Koji je najveci nogometni stadion na svijetu?",
            "Tko je bio trener Real Madrida od 2016 do 2021. godine?",
            "Tko je osvojio zlatnu kopačku na svjetskom prvenstvu 2018. godine?",
            "Koji je bio zadnji klub za kojeg je igrao Zlatan Ibrahimović?",
            "Koje godine je osnovan Man. United?",

    };

    public static String choices[][] = {
            {"Lionel Messi","Cristiano Ronaldo","Kylian Mbappé","Zlatan Ibrahimović"},
            {"Phil Foden","Cole Palmer","Erling Haaland","Mohamed Salah"},
            {"Lionel Messi","Pelé","Cristiano Ronaldo","Diego Maradona"},
            {"Karim Benzema","Neymar","Zinédine Zidane","Sergio Ramos"},
            {"2019","2020","2021","2022"},
            {"Sergio Ramos","Felipe Melo","Rafael Marquez","Cyril Rool"},
            {"4","3","2","1"},
            {"Marcus Rashford","Lionel Messi","Pedri","Kobbie Mainoo"},
            {"2011","2010","2009","2008"},
            {"Dominik Livaković","Andries Noppert","Wojciech Szczęsny","Emiliano Martinez"},
            {"2023","2022","2021","2020"},
            {"5","4","3","2"},
            {"Man. United - Barcelona","Man. City - Inter","Real Madrid - Dortmund","Liverpool - Arsenal"},
            {"Erling Haaland","Phil Foden","Vinícius Júnior","Jude Bellingham"},
            {"2010","2009","2008","2007"},
            {"Camp Nou","Melbourne Cricket Ground","Rose Bowl","Rungrado"},
            {"Carlo Ancelotti","Zinédine Zidane","Santiago Solari","Julen Lopetegui"},
            {"Neymar","Kylian Mbappé","Luka Modrić","Harry Kane"},
            {"Arsenal","Barcelona","Milan"," Juventus"},
            {"1876","1877","1878"," 1879"},

    };

    public static String correctAnswers[] = {
            "Cristiano Ronaldo",
            "Erling Haaland",
            "Lionel Messi",
            "Neymar",
            "2021",
            "Sergio Ramos",
            "3",
            "Pedri",
            "2008",
            "Dominik Livaković",
            "2021",
            "2",
            "Man. City - Inter",
            "Phil Foden",
            "2008",
            "Rungrado",
            "Zinédine Zidane",
            "Harry Kane",
            "Milan",
            "1878",

    };

}

