package com.example.aplikacije;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class Kviz extends AppCompatActivity implements View.OnClickListener{

    TextView totalQuestionsTextView;
    TextView questionTextView;
    Button ansA, ansB, ansC, ansD;
    Button submitBtn;

    int score=0;
    int totalQuestion = pitanjaOdgovori.question.length;
    int currentQuestionIndex = 0;
    String selectedAnswer = "";
    private Button povratak;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kviz);

        totalQuestionsTextView = findViewById(R.id.total_question);
        questionTextView = findViewById(R.id.question);
        ansA = findViewById(R.id.ans_A);
        ansB = findViewById(R.id.ans_B);
        ansC = findViewById(R.id.ans_C);
        ansD = findViewById(R.id.ans_D);
        submitBtn = findViewById(R.id.submit_btn);
        povratak = findViewById(R.id.buttonpovratak);

        ansA.setOnClickListener(this);
        ansB.setOnClickListener(this);
        ansC.setOnClickListener(this);
        ansD.setOnClickListener(this);
        submitBtn.setOnClickListener(this);

        totalQuestionsTextView.setText("Broj pitanja : "+totalQuestion);

        loadNewQuestion();

        povratak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Kviz.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }




    @Override
    public void onClick(View view) {

        ansA.setBackgroundColor(Color.WHITE);
        ansB.setBackgroundColor(Color.WHITE);
        ansC.setBackgroundColor(Color.WHITE);
        ansD.setBackgroundColor(Color.WHITE);

        Button clickedButton = (Button) view;
        if(clickedButton.getId()==R.id.submit_btn){
            if(selectedAnswer.equals(pitanjaOdgovori.correctAnswers[currentQuestionIndex])){
                score++;
                CharSequence text = "Točno!";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(this, text, duration);
                toast.show();
            }
            else{
                CharSequence text1 = "Netočno!";
                int duration1 = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(this, text1, duration1);
                toast.show();
            }
            currentQuestionIndex++;
            loadNewQuestion();



        }else{
            selectedAnswer  = clickedButton.getText().toString();
            clickedButton.setBackgroundColor(Color.MAGENTA);


        }

    }

    void loadNewQuestion(){

        if(currentQuestionIndex == totalQuestion ){
            finishQuiz();
            return;
        }

        questionTextView.setText(pitanjaOdgovori.question[currentQuestionIndex]);
        ansA.setText(pitanjaOdgovori.choices[currentQuestionIndex][0]);
        ansB.setText(pitanjaOdgovori.choices[currentQuestionIndex][1]);
        ansC.setText(pitanjaOdgovori.choices[currentQuestionIndex][2]);
        ansD.setText(pitanjaOdgovori.choices[currentQuestionIndex][3]);

    }

    void finishQuiz(){
        String passStatus = "";
        if(score > totalQuestion*0.60){
            passStatus = "Prolaz";
        }else{
            passStatus = "Pokušaj ponovo";
        }

        new AlertDialog.Builder(this)
                .setTitle(passStatus)
                .setMessage("Score: "+ score+" od "+ totalQuestion)
                .setPositiveButton("Ponovo pokreni",(dialogInterface, i) -> restartQuiz() )
                .setCancelable(false)
                .show();


    }

    void restartQuiz(){
        score = 0;
        currentQuestionIndex =0;
        loadNewQuestion();
    }

}