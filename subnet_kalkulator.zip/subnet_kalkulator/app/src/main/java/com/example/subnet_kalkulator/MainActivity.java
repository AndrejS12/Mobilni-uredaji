package com.example.subnet_kalkulator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    private EditText ipPart1, ipPart2, ipPart3, ipPart4;
    private Button calculateBtn;
    private TextView resultView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ipPart1 = findViewById(R.id.ipPart1);
        ipPart2 = findViewById(R.id.ipPart2);
        ipPart3 = findViewById(R.id.ipPart3);
        ipPart4 = findViewById(R.id.ipPart4);
        calculateBtn = findViewById(R.id.calculateBtn);
        resultView = findViewById(R.id.resultView);

        calculateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateSubnet();
            }
        });
    }

    private void calculateSubnet() {
        String part1 = ipPart1.getText().toString().trim();
        String part2 = ipPart2.getText().toString().trim();
        String part3 = ipPart3.getText().toString().trim();
        String part4 = ipPart4.getText().toString().trim();

        //Jesu li sva polja popunjena
        if (part1.isEmpty() || part2.isEmpty() || part3.isEmpty() || part4.isEmpty()) {
            resultView.setText("Greška!");
            return;
        }

        int[] ipParts = {Integer.parseInt(part1), Integer.parseInt(part2),
                Integer.parseInt(part3), Integer.parseInt(part4)};

        Da li su brojevi ispravni (0-255)
        for (int num : ipParts) {
            if (num < 0 || num > 255) {
                resultView.setText("Neispravna IP adresa!");
                return;
            }
        }

        // /26 maska: 255.255.255.192
        int[] subnetMask = {255, 255, 255, 192};

        // Mrežna adresa
        int[] networkAddress = {
                ipParts[0] & subnetMask[0],
                ipParts[1] & subnetMask[1],
                ipParts[2] & subnetMask[2],
                ipParts[3] & subnetMask[3]
        };

        // Broadcast adresa
        int[] broadcastAddress = {
                networkAddress[0] | (255 - subnetMask[0]),
                networkAddress[1] | (255 - subnetMask[1]),
                networkAddress[2] | (255 - subnetMask[2]),
                networkAddress[3] | (255 - subnetMask[3])
        };

        // Prvi i zadnji host
        int[] firstHost = {networkAddress[0], networkAddress[1], networkAddress[2], networkAddress[3] + 1};
        int[] lastHost = {broadcastAddress[0], broadcastAddress[1], broadcastAddress[2], broadcastAddress[3] - 1};

        // Formatiranje binarnog oblika
        String binaryIP = String.format("%8s.%8s.%8s.%8s",
                Integer.toBinaryString(ipParts[0]),
                Integer.toBinaryString(ipParts[1]),
                Integer.toBinaryString(ipParts[2]),
                Integer.toBinaryString(ipParts[3])
        ).replace(" ", "0");

        String result = "IP adresa: " + formatIP(ipParts) + "\n"
                + "Binarni oblik: " + binaryIP + "\n\n"
                + "Subnet maska: 255.255.255.192\n"
                + "Mrežna adresa: " + formatIP(networkAddress) + "\n"
                + "Broadcast adresa: " + formatIP(broadcastAddress) + "\n"
                + "Prvi host: " + formatIP(firstHost) + "\n"
                + "Zadnji host: " + formatIP(lastHost) + "\n"
                + "Broj hostova: 62";

        resultView.setText(result);
    }

    private String formatIP(int[] ip) {
        return ip[0] + "." + ip[1] + "." + ip[2] + "." + ip[3];
    }
}
