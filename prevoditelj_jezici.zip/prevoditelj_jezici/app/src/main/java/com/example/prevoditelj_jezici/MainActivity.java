package com.example.prevoditelj_jezici;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    // Definiranje varijabli elemenata aplikacije
    private TextView Rezultat, Rezultat2, Rezultat3, Rezultat4, Rezultat5;
    private Button Izracun;
    private Spinner spinner;
    private EditText Unos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Pronalazak elemenata putem ID-a
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        Rezultat = findViewById(R.id.TextViewRez);
        Rezultat2 = findViewById(R.id.TextViewRez2);
        Rezultat3 = findViewById(R.id.TextViewRez3);
        Rezultat4 = findViewById(R.id.TextViewRez4);
        Rezultat5 = findViewById(R.id.TextViewRez5);
        Izracun = findViewById(R.id.Izracunaj);
        spinner = findViewById(R.id.Spinner_prvi);

        // Definiranje liste jezika za spinner
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("Hrvatski");
        arrayList.add("Engleski");
        arrayList.add("Njemački");
        arrayList.add("Francuski");
        arrayList.add("Španjolski");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, arrayList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        // Postavljanje OnClickListener-a na dugme
        Izracun.setOnClickListener(view -> Prevedi());
    }

    // Metoda za prevođenje
    public void Prevedi() {
        String jezik = spinner.getSelectedItem().toString();

        if (jezik.equals("Engleski")) {
            Rezultat.setText("apple, pear, plum, banana, cherry");
            Rezultat2.setText("football, basketball, tennis, volleyball, handball");
            Rezultat3.setText("mathematics, physics, history, biology, religious education");
            Rezultat4.setText("pants, jacket, sneakers, scarf, hat");
            Rezultat5.setText("chair, table, wardrobe, bed, carpet");
        } else if (jezik.equals("Njemački")) {
            Rezultat.setText("Apfel, Birne, Pflaume, Banane, Kirsche");
            Rezultat2.setText("Fußball, Basketball, Tennis, Volleyball, Handball");
            Rezultat3.setText("Mathematik, Physik, Geschichte, Biologie, Religionsunterricht");
            Rezultat4.setText("Hose, Jacke, Turnschuhe, Schal, Hut");
            Rezultat5.setText("Stuhl, Tisch, Kleiderschrank, Bett, Teppich");
        } else if (jezik.equals("Francuski")) {
            Rezultat.setText("pomme, poire, prune, banane, cerise");
            Rezultat2.setText("football, basket-ball, tennis, volley-ball, handball");
            Rezultat3.setText("mathématiques, physique, histoire, biologie, éducation religieuse");
            Rezultat4.setText("pantalon, veste, baskets, écharpe, chapeau");
            Rezultat5.setText("chaise, table, armoire, lit, tapis");
        } else if (jezik.equals("Španjolski")) {
            Rezultat.setText("manzana, pera, ciruela, plátano, cereza");
            Rezultat2.setText("fútbol, baloncesto, tenis, voleibol, balonmano");
            Rezultat3.setText("matemáticas, física, historia, biología, educación religiosa");
            Rezultat4.setText("pantalones, chaqueta, zapatillas, bufanda, sombrero");
            Rezultat5.setText("silla, mesa, armario, cama, alfombra");
        } else {
            Rezultat.setText("jabuka, kruška, šljiva, banana, trešnja");
            Rezultat2.setText("nogomet, košarka, tenis, odbojka, rukomet");
            Rezultat3.setText("matematika, fizika, povijest, biologija, vjeronauk");
            Rezultat4.setText("hlače, jakna, tenisice, šal, kapa");
            Rezultat5.setText("stolica, stol, ormar, krevet, tepih");
        }
    }
}