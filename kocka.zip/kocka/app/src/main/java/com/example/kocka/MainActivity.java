package com.example.kocka;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private ImageView ImageViewSlika;

    private TextView TextViewBroj;

    private Random random = new Random();

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextViewBroj = findViewById(R.id.TextViewBr);
        ImageViewSlika = findViewById(R.id.ImageViewKocka);
        ImageViewSlika.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Baci();
            }
        });
    }

        private void Baci(){
            int i = random.nextInt(6)+1;
            switch(i) {
                case 1:
                    ImageViewSlika.setImageResource(R.drawable.perspective_dice_six_faces_one);
                    TextViewBroj.setText("1");
                    break;
                case 2:
                    ImageViewSlika.setImageResource(R.drawable.perspective_dice_six_faces_two);
                    TextViewBroj.setText("2");
                    break;
                case 3:
                    ImageViewSlika.setImageResource(R.drawable.perspective_dice_six_faces_three);
                    TextViewBroj.setText("3");
                    break;
                case 4:
                    ImageViewSlika.setImageResource(R.drawable.perspective_dice_six_faces_four);
                    TextViewBroj.setText("4");
                    break;
                case 5:
                    ImageViewSlika.setImageResource(R.drawable.perspective_dice_six_faces_five);
                    TextViewBroj.setText("5");
                    break;
                case 6:
                    ImageViewSlika.setImageResource(R.drawable.perspective_dice_six_faces_six);
                    TextViewBroj.setText("6");
                    break;
            }
        }

    }




