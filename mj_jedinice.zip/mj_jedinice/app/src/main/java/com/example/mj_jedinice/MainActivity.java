package com.example.mj_jedinice;

import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    //Definiranje varijabli elemenata aplikacije
    private TextView Rezultat;
    public Button Izracun;

    public Spinner spinner;

    public Spinner spinner_drugi;

    public EditText Unos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Traženenje elemenata pomoću ID-a
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        Unos = findViewById(R.id.EditTextUnos);
        Rezultat = findViewById(R.id.TextViewRez);
        Izracun = findViewById(R.id.Izracunaj);
        spinner = findViewById(R.id.Spinner_prvi);
        spinner_drugi = findViewById(R.id.Spinner_drugi);

        //Definiranje oba izbornika

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                String item = adapterView.getItemAtPosition(position).toString();
                Toast.makeText(MainActivity.this, "Odabir: " + item, Toast.LENGTH_SHORT).show(); //Izbacuje nam poruku koju smo mj jednicu odabrali
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinner_drugi.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                String item = adapterView.getItemAtPosition(position).toString();
                Toast.makeText(MainActivity.this, "Odabir: " + item, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        //Metoda koja se pokreće kada kliknemo na button
        Izracun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = Unos.getText().toString(); // Spremanje EditTexta u String varijablu
                if(text.isEmpty()){                                 //Provjerava je li varijabla prazna i ako je ispisuje poruku da se unese vrijdnost u EditText polje
                    Rezultat.setText("Unesite vrijednost!");
                }
                else {
                    double input = Double.parseDouble(Unos.getText().toString());  // Dohvaćanje vrijesnoti od EditTexta, prvog i drugog izbornika
                    String fromUnit = spinner.getSelectedItem().toString();
                    String toUnit = spinner_drugi.getSelectedItem().toString();


                    convertUnits(input, fromUnit, toUnit); // Poziva se metoda koja računa mjerne jedinice (unosimo sva tri parametra koja funkcija prima)
                }

            }
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ArrayList<String> arrayList = new ArrayList<>(); // Definiranje dvije String liste za oba izbornika
        arrayList.add("m"); // Unos svih opcija izbornika
        arrayList.add("cm");
        arrayList.add("mm");
        arrayList.add("dm");
        arrayList.add("km");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, arrayList);
        adapter.setDropDownViewResource(android.R.layout.select_dialog_singlechoice);
        spinner.setAdapter(adapter); // Kreiramo adapter koji povezuje izbornik sa string listom u kojoj se nalaze opcije te se postavlja izgled izbornika


        ArrayList<String> arrayList_drugi = new ArrayList<>();
        arrayList_drugi.add("m");
        arrayList_drugi.add("cm");
        arrayList_drugi.add("mm");
        arrayList_drugi.add("dm");
        arrayList_drugi.add("km");

        ArrayAdapter<String> adapter_drugi = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, arrayList_drugi);
        adapter_drugi.setDropDownViewResource(android.R.layout.select_dialog_singlechoice);
        spinner_drugi.setAdapter(adapter);


    }


// Funkcija koja pretvara mjerne jedinice iz jedne u drugu
// Funkcija prima 3 parametra: input(Broj koji unesemo), fromUnit(vrijednost prvog izbornika), toUnit(vrijesnot drugog izbornika)
// Ovdje su sve kombinacije pretvorbi, kada zavrsi izračun postavi rezultat u TextView
    private void convertUnits(double input, String fromUnit, String toUnit) {
        if (fromUnit.equals("m") && toUnit.equals("km")) {
            double rez = input / 1000;
            Rezultat.setText(Double.toString(rez));
        } else if (fromUnit.equals("m") && toUnit.equals("cm")) {
            double rez = input * 100;
            Rezultat.setText(Double.toString(rez));
        } else if (fromUnit.equals("m") && toUnit.equals("mm")) {
            double rez = input * 1000;
            Rezultat.setText(Double.toString(rez));
        } else if (fromUnit.equals("m") && toUnit.equals("dm")) {
            double rez = input * 10;
            Rezultat.setText(Double.toString(rez));
        } else if (fromUnit.equals("km") && toUnit.equals("m")) {
            double rez = input * 1000;
            Rezultat.setText(Double.toString(rez));
        } else if (fromUnit.equals("km") && toUnit.equals("cm")) {
            double rez = input * 100000;
            Rezultat.setText(Double.toString(rez));
        } else if (fromUnit.equals("km") && toUnit.equals("mm")) {
            double rez = input * 1000000;
            Rezultat.setText(Double.toString(rez));
        } else if (fromUnit.equals("km") && toUnit.equals("dm")) {
            double rez = input * 10000;
            Rezultat.setText(Double.toString(rez));
        } else if (fromUnit.equals("cm") && toUnit.equals("m")) {
            double rez = input / 100;
            Rezultat.setText(Double.toString(rez));
        } else if (fromUnit.equals("cm") && toUnit.equals("km")) {
            double rez = input / 100000;
            Rezultat.setText(Double.toString(rez));
        } else if (fromUnit.equals("cm") && toUnit.equals("mm")) {
            double rez = input * 10;
            Rezultat.setText(Double.toString(rez));
        } else if (fromUnit.equals("cm") && toUnit.equals("dm")) {
            double rez = input / 10;
            Rezultat.setText(Double.toString(rez));
        } else if (fromUnit.equals("mm") && toUnit.equals("m")) {
            double rez = input / 1000;
            Rezultat.setText(Double.toString(rez));
        } else if (fromUnit.equals("mm") && toUnit.equals("km")) {
            double rez = input / 1000000;
            Rezultat.setText(Double.toString(rez));
        } else if (fromUnit.equals("mm") && toUnit.equals("cm")) {
            double rez = input / 10;
            Rezultat.setText(Double.toString(rez));
        } else if (fromUnit.equals("mm") && toUnit.equals("dm")) {
            double rez = input / 100;
            Rezultat.setText(Double.toString(rez));
        } else if (fromUnit.equals("dm") && toUnit.equals("m")) {
            double rez = input / 10;
            Rezultat.setText(Double.toString(rez));
        } else if (fromUnit.equals("dm") && toUnit.equals("km")) {
            double rez = input / 10000;
            Rezultat.setText(Double.toString(rez));
        } else if (fromUnit.equals("dm") && toUnit.equals("cm")) {
            double rez = input * 10;
            Rezultat.setText(Double.toString(rez));
        } else if (fromUnit.equals("dm") && toUnit.equals("mm")) {
            double rez = input * 100;
            Rezultat.setText(Double.toString(rez));
        } else {
            Rezultat.setText(Double.toString(input)); // Ako su jedinice iste, nema pretvorbe
        }


    }


}