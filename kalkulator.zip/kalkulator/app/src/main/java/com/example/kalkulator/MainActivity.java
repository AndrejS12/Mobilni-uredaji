package com.example.kalkulator;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {


    private double Broj1, Broj2;
    private TextView Rezultat;
    private EditText prvi_broj, drugi_broj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);

            Rezultat = findViewById(R.id.rezultat);
            prvi_broj = findViewById(R.id.prvi_broj);
            drugi_broj = findViewById(R.id.drugi_broj);

            return insets;





        });
    }

    public void takeNumbersFromEditTextAndPutIntoVariables() {
        String broj1Text = prvi_broj.getText().toString();
        String broj2Text = drugi_broj.getText().toString();

        if (!broj1Text.isEmpty() && !broj2Text.isEmpty()) {
            Broj1 = Double.parseDouble(broj1Text);
            Broj2 = Double.parseDouble(broj2Text);
        } else {

            Rezultat.setText("Unesite oba broja");
        }
    }


    public void Zbrajanje(View view){

        takeNumbersFromEditTextAndPutIntoVariables();
        double rez = Broj1 + Broj2;
        Rezultat.setText(Double.toString(rez));

    }
    public void Oduzimanje(View view){
        takeNumbersFromEditTextAndPutIntoVariables();
        double rez = Broj1 - Broj2;
        Rezultat.setText(Double.toString(rez));
    }
    public void Mnozenje(View view){
        takeNumbersFromEditTextAndPutIntoVariables();
        double rez = Broj1 * Broj2;
        Rezultat.setText(Double.toString(rez));
    }
    public void Dijeljenje(View view){
        takeNumbersFromEditTextAndPutIntoVariables();
        double rez = Broj1 / Broj2;
        Rezultat.setText(Double.toString(rez));
    }
}